package de.uni_passau.fim.prog1.pyramid_math;

import java.util.Scanner;

public class PyramidVolume {
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter the size of the cuboid:");
        System.out.print("Length: ");
        double cuboidLength = in.nextDouble(); // Read a double value from the user input.
        in.nextLine(); // Skip everything until after the next newline.

        System.out.print("Width: ");
        double cuboidWidth = in.nextDouble(); // Read a double value from the user input.
        in.nextLine(); // Skip everything until after the next newline.

        System.out.print("Height: ");
        double cuboidHeight = in.nextDouble(); // Read a double value from the user input.
        in.nextLine(); // Skip everything until after the next newline.
        
        System.out.print("Enter the height of the pyramid: ");
        double pyramidHeight = in.nextDouble(); // Read a double value from the user input.
        in.nextLine(); // Skip everything until after the next newline.
        
        double cuboidVol = cuboidLength * cuboidWidth * cuboidHeight; // calculate the cuboid's volume
        double pyramidVol = (cuboidLength * cuboidWidth * pyramidHeight) / 3; // calculate the pyramids volume
        double volumeSum = cuboidVol + pyramidVol; // calculates the sum of the cuboid's and the pyramids volume
        
        System.out.println("The volume of the figure is: " + volumeSum);

        // Alle Kommentare zu den calculations sind eigentlich unnötig da im Code ersichtlich
    }
}
