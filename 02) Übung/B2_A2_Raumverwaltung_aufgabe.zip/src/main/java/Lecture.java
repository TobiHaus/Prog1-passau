public class Lecture {
    // Auf Konventionen wie Kleinschreibung von Attributen sowie die englische Sprache wurde aufgrund
    // der Dokumentation auf dem Uebungsblatt bewusst verzichtet, damit diese mit dem Code uebereinstimmt.
    private String Titel;
    private int Vorlesungsnummer;
    private Professor Dozent;
}