public class Professor{
    private String Name;
    private String Vorname;
    private String Lehrstuhl_ID;
    private int Bueronummer;
}