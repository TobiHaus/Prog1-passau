public class ADRESS {
    private int zipCode;
    private String streetNumber;
    private String city;
    private String street;
}
