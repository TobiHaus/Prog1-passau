package de.uni_passau.fim.prog1.data_query;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * Utility class for executing the {@link #main(String[])} method.
 */
public class Query {

    /**
     * Asks some questions on the command line and outputs a summary of the queried info.
     *
     * @param args command line arguments -- ignored
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Please enter your name:");
        String name = in.next();
        in.nextLine();

        System.out.println("Please enter your age:");
        int age = in.nextInt();
        in.nextLine();

        System.out.println("Please enter your field of study:");
        String field = in.next();
        in.nextLine();

        System.out.println("You entered the following data:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Field of study: " + field);

    }
}
