package de.uni_passau.fim.prog1.degree;

/**
 * A temperature that can be set and accessed in both fahrenheit and celsius.
 */
class Temperature {
    
    // Definieren Sie das Attribut 'degreesCelsius' hier.
    double degreesCelsius;

    /**
     * Sets the represented temperature in celsius.
     *
     * @param degreesCelsius the new temperature in degrees celsius
     */
    // Definieren Sie die 'setDegreesCelsius' Methode hier.
    public void setDegreesCelsius(double degreesCelsius){
        this.degreesCelsius = degreesCelsius;
    }

    /**
     * Returns the represented temperature in celsius.
     *
     * @return the temperature in degrees celsius
     */
    // Definieren Sie die 'getDegreesCelsius' Methode hier.
    public double getDegreesCelsius(){
        return degreesCelsius;
    }

    /**
     * Sets the represented temperature in fahrenheit.
     *
     * @param degreesFahrenheit the new temperature in degrees fahrenheit
     */
    // Definieren Sie die 'setDegreesFahrenheit' Methode hier.
    public void setDegreesFahrenheit(double degreesFahrenheit){
        degreesCelsius = (degreesFahrenheit - 32) * 5/9; //formula for fahrenheit to celsius based on worksheet
    }

    /**
     * Returns the represented temperature in fahrenheit.
     *
     * @return the temperature in degrees fahrenheit
     */
    // Definieren Sie die 'getDegreesFahrenheit' Methode hier.
    public double getDegreesFahrenheit(){
        return (degreesCelsius * 5/9) + 32;
    }
}
