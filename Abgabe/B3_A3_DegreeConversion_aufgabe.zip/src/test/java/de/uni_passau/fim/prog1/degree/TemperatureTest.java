package de.uni_passau.fim.prog1.degree;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static java.lang.String.format;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class TemperatureTest {

    private static final double DEGREES_CELSIUS = 0;
    private static final double NEW_DEGREES_CELSIUS = 26;
    private static final double DEGREES_FAHRENHEIT = 90;

    private static Class<?> temperatureClass;
    private static Field temperatureField;

    private Object temperature;

    @BeforeAll
    public static void init() throws Exception {
        String pName = "de.uni_passau.fim.prog1.degree";
        String cName = "Temperature";
        String fName = "degreesCelsius";

        temperatureClass = findClass(pName, cName);
        temperatureField = findField(temperatureClass, fName, double.class);
    }

    @BeforeEach
    public void setUp() throws Exception {
        temperature = temperatureClass.getDeclaredConstructor().newInstance();
        temperatureField.setDouble(temperature, DEGREES_CELSIUS);
    }

    @Test
    public void setDegreesCelsius() throws Exception {
        Method setDegreesCelsius = findMethod(temperatureClass, "setDegreesCelsius", void.class, double.class);

        setDegreesCelsius.invoke(temperature, NEW_DEGREES_CELSIUS);
        assertEquals(NEW_DEGREES_CELSIUS, temperatureField.getDouble(temperature), 0.01, "Die Temperatur in °C wird nicht korrekt gesetzt.");
    }

    @Test
    public void getDegreesCelsius() throws Exception {
        Method getDegreesCelsius = findMethod(temperatureClass, "getDegreesCelsius", double.class);
        double actual = (Double) getDegreesCelsius.invoke(temperature);

        assertEquals(DEGREES_CELSIUS, actual, 0.01, "Die Temperatur in °C wird nicht korrekt zurückgegeben.");
    }

    @Test
    public void setDegreesFahrenheit() throws Exception {
        Method setDegreesFahrenheit = findMethod(temperatureClass, "setDegreesFahrenheit", void.class, double.class);

        setDegreesFahrenheit.invoke(temperature, DEGREES_FAHRENHEIT);
        assertEquals(DEGREES_FAHRENHEIT, temperatureField.getDouble(temperature) * 1.8 + 32, 0.01, "Die Temperatur in °F wird nicht korrekt gesetzt.");
    }

    @Test
    public void getDegreesFahrenheit() throws Exception {
        Method getDegreesFahrenheit = findMethod(temperatureClass, "getDegreesFahrenheit", double.class);
        double actual = (Double) getDegreesFahrenheit.invoke(temperature);

        assertEquals(DEGREES_CELSIUS * 1.8 + 32, actual, 0.01, "Die Temperatur in °F wird nicht korrekt zurückgegeben.");
    }

    private static Class<?> findClass(String packageName, String className) {
        Class<?> clazz = null;
        String failMsg = null;

        try {
            if (packageName == null || packageName.isEmpty()) {
                failMsg = format("Die Klasse '%s' wurde nicht im default Paket gefunden.", className);
                clazz = Class.forName(className);
            } else {
                failMsg = format("Die Klasse '%s' wurde nicht im Paket '%s' gefunden.", className, packageName);
                clazz = Class.forName(packageName + "." + className);
            }
        } catch (ClassNotFoundException e) {
            fail(failMsg);
        }

        return clazz;
    }

    private static Field findField(Class<?> clazz, String fieldName, Class<?> expectedType) {
        Field field = null;

        try {
            field = clazz.getDeclaredField(fieldName);
        } catch (NoSuchFieldException e) {
            fail(format("Das Attribut '%s' wurde in der Klasse '%s' nicht gefunden.", fieldName, clazz.getSimpleName()));
        }

        String msg = format("Das Attribut '%s' hat nicht den erwarteten Typ '%s'.", fieldName, expectedType.getSimpleName());
        assertEquals(expectedType, field.getType(), msg);

        return field;
    }

    private Method findMethod(Class<?> clazz, String name, Class<?> expectedRetType, Class<?>... expectedParTypes) {
        Method method = null;

        try {
            method = clazz.getDeclaredMethod(name, expectedParTypes);
        } catch (NoSuchMethodException e) {
            fail(format("Die Methode '%s' wurde in der Klasse '%s' nicht gefunden.", name, clazz.getSimpleName()));
        }

        String msg = format("Die Methode '%s' hat nicht den erwarteten Rückgabetyp '%s'.", name, expectedRetType.getSimpleName());
        assertEquals(expectedRetType, method.getReturnType(), msg);

        return method;
    }
}
