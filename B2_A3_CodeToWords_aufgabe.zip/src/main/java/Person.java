class Person {
    private HUMAN_DATA data;
    private ADRESS adress;
}