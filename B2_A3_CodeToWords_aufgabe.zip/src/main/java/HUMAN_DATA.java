public class HUMAN_DATA {
    private String firstName;
    private String lastName;
    private String age;

    // ...
}
