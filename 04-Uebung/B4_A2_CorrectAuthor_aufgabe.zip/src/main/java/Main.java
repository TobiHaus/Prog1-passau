import java.time.LocalDate;

/**
 * Contains the {@link #main(String[])} method testing the implementation of the 
 * {@link Author} class.
 */
public class Main {

    public static final String NAME = "Neil";
    public static final String SURNAME = "Gaiman";
    public static final LocalDate DOB = LocalDate.of(1969, 11, 20);
    public static final String HOME_PAGE = "http://www.neilgaiman.com/";
    public static final String BIO = "Neil Gaiman ist ein britischer Autor von Comics und Romanen. " +
            "Bekannt wurde er durch Romane wie \"American Gods\", \"Niemalsland\" " +
            "und die Comicreihe \"Der Sandmann\".";

    /**
     * Tests the implementation of the {@link Author} class.
     *
     * @param args
     *            command line arguments, ignored
     */
    public static void main(String[] args) {
        Author author = new Author(NAME, SURNAME, DOB, HOME_PAGE, BIO);
        author.print();
    }
}
