import java.time.LocalDate;

/**
 * The {@link Author} class models the author of a work. It includes some basic
 * information like the date of birth and a short biography.
 */
class Author {
    
    String firstName;
    String lastName;

    LocalDate dateOfBirth;

    String homePage;
    String bio;

    /**
     * Constructs a new {@link Author}.
     *
     * @param firstName
     *            the first name of the author
     * @param lastName
     *            the last name of the author
     * @param dateOfBirth
     *            the date of birth of the author
     * @param homePage
     *            the homepage of the author
     * @param bio
     *            the short biography of the author
     */
    Author(String firstName, String lastName, LocalDate dateOfBirth,
                  String homePage, String bio) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.homePage = homePage;
        this.bio = bio;
    }

    /**
     * Returns the full name of the author in the format
     * "[firstName] [lastName]".
     *
     * @return the full name of the author
     */
    String getFullName() {
        return lastName;
    }

    /**
     * Returns the date of birth of the author.
     *
     * @return the date of birth of the author
     */
    LocalDate getDateOfBirth() {
        return dateOfBirth;
    }
    public String getHomePage(){return homePage; }
    public String getBio() { return bio; }

    /**
     * Prints a multi-line representation of this {@link Author} to the console.
     */
    void print() {
        System.out.println("Name: " + getFullName());
        System.out.println("Geburtsdatum: " + getDateOfBirth());
        System.out.println("Offizielle Homepage: " + getHomePage());
        System.out.println("Biografie:");
        System.out.println(getBio());
    }
}
