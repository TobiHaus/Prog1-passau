import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests the functionality of the {@link Author} class.
 */
public class AuthorTest {

    private static final String[] EXPECTED = {
            "Name: " + Main.NAME + " " + Main.SURNAME,
            "Geburtsdatum: " + Main.DOB,
            "Offizielle Homepage: " + Main.HOME_PAGE,
            "Biografie:",
            Main.BIO};

    /**
     * Tests whether the correct output is produced by the {@link Author#print()} method.
     */
    @Test
    public void print() throws Exception {

        PipedInputStream in = new PipedInputStream();
        Scanner sout = new Scanner(in);

        System.setOut(new PrintStream(new PipedOutputStream(in)));

        Author author = new Author(Main.NAME, Main.SURNAME, Main.DOB, Main.HOME_PAGE, Main.BIO);
        author.print();

        System.out.close();

        for (int i = 0; i < EXPECTED.length; i++) {
            assertTrue(sout.hasNextLine(), "Es wurden nicht genug Zeilen ausgegeben.");
            assertEquals(EXPECTED[i], sout.nextLine(), "Zeile " + i + " wurde nicht korrekt ausgegeben.");
        }
    }
}