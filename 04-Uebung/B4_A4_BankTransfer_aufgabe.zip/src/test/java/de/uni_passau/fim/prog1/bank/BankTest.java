package de.uni_passau.fim.prog1.bank;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BankTest {
    @Test
    void test_deposit() {
        Account a = new Account("Monika");
        a.deposit(123.4f);
        assertEquals(123.4f, a.getBalance());
    }

    @Test
    void test_toString() {
        Account a = new Account("Monika");
        a.deposit(234.56f);
        String str = a.toString();
        assertTrue(str.contains("Monika"));  // account holder
        assertTrue(str.contains("234.56"));  // balance
        assertTrue(str.contains("1"));       // number of transactions
    }

    @Test
    void test_withdraw() {
        Account a = new Account("Monika");
        a.deposit(100);
        assertFalse(a.withdraw(200));
        assertEquals(100, a.getBalance());
    }

    @Test
    void test_monthlyStatement() {
        Account a = new Account("Monika");
        a.deposit(100);  // 1 transaction
        a.withdraw(200); // counts as 2 transactions
        a.withdraw(50);  // 1 transaction
        a.monthlyStatement();  // costs 1.5 + 4*0.10 = 1.9 units
        assertEquals(48.1f, a.getBalance());
        // transaction counter should be 0 now
        a.monthlyStatement();  // costs 1.5 units
        assertEquals(46.6f, a.getBalance());
    }

    @Test
    void test_Transfer_successful() {
        Account a = new Account("A");
        Account b = new Account("B");
        a.deposit(100);
        b.deposit(50);
        Transfer t = new Transfer(a, b, 40);
        t.execute();
        assertEquals(60, a.getBalance());
        assertEquals(90, b.getBalance());
    }

    @Test
    void test_Transfer_not_successful() {
        Account a = new Account("A");
        Account b = new Account("B");
        a.deposit(100);
        b.deposit(50);
        Transfer t = new Transfer(a, b, 110);
        t.execute();
        assertEquals(100, a.getBalance());
        assertEquals(50, b.getBalance());
    }
}