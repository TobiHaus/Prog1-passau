package de.uni_passau.fim.prog1.bank;

/**
 * Represents a money transfer between two accounts.
 */
class Transfer {
    
    public Account sender;
    public Account receiver;
    public float amount;

    /**
     * Construct a bank transfer. The sending account, the receiving account
     * and the amount to transfer need to be given.
     *
     * @param sender the account which sends the money
     * @param receiver the account which receives the money
     * @param amount how much money to transfer
     */
    public Transfer(Account sender, Account receiver, float amount){
        this.sender = sender;
        this.receiver = receiver;
        this.amount = amount;
    }
    
    /**
     * Executes the transfer. The money is only
     * deposited on the receiving account if the withdrawal
     * from the sending account has been successful.
     */
    public void execute(){
        if(amount > 0) {    //Schützt vor Angriffen, wo ein negativer Betrag gesendet wird, der Sender also praktisch Geld vom receiver bekommt
            if (sender.getBalance() >= amount) {
                sender.withdraw(amount);
                receiver.deposit(amount);
            }
            else {
                System.out.println("Der Sender hat zu wenig Geld");
            }
        }
        else{
            System.out.println("Sie können keinen negativen Betrag senden!");
        }
    }
}
