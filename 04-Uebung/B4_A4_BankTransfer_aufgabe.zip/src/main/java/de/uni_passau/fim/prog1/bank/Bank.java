package de.uni_passau.fim.prog1.bank;

class Bank {
    public static void main(String[] args) {

        Account a = new Account("Anna Consultant");
        Account b = new Account("Betty Programmer");
        Account k = new Account("Karl Knappbeikasse");

        a.deposit(1000);
        b.deposit(500);
        k.deposit(20);

        a.withdraw(50);  // should succeed
        k.withdraw(100); // should fail

        // Show information about accounts
        System.out.println(a);
        System.out.println(b);
        System.out.println(k);

        Transfer t1 = new Transfer(k, a, 200);
        t1.execute();   // should not transfer any money
        System.out.println(a);
        System.out.println(k);

        Transfer t2 = new Transfer(b, k, 200);
        t2.execute();   // should transfer money
        System.out.println(b);
        System.out.println(k);

        a.monthlyStatement();
        b.monthlyStatement();
        k.monthlyStatement();

        System.out.println(a);
        System.out.println(b);
        System.out.println(k);

    }
}
